using System;
using System.Collections.Generic;
using System.Text;
public abstract class JobOffer
{
    private string jobTitle;

    public string JobTitle
    {
        get { 
            //TODO: Implement me...
            throw new NotImplementedException();
        }
        set
        {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
    }

    private string company;

    public string Company
    {
        get {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
        set
        {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
    }

    private double salary;

    public double Salary
    {
        get {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
        set { 
            //TODO: Implement me...
            throw new NotImplementedException();
        }
    }

    public JobOffer(string jobTitle, string company, double salary)
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public override string ToString()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

}
