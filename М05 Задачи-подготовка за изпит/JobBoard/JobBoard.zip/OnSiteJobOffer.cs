using System;
using System.Collections.Generic;
using System.Text;


public class OnSiteJobOffer : JobOffer
{
    private string city;

    public string City
    {
        get {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
        
        set
        {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
    }

    public OnSiteJobOffer(string jobTitle, string company, double salary, string city) : base(jobTitle, company, salary)
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public override string ToString()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }
}

