using System;
using System.Collections.Generic;
using System.Text;

public class RemoteJobOffer : JobOffer
{
    private bool fullyRemote;

    public RemoteJobOffer(string jobTitle, string company, double salary, bool fullyRemote) : base(jobTitle, company, salary)
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public bool FullyRemote
    {
        get {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
        set {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
    }

    public override string ToString()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }
}

