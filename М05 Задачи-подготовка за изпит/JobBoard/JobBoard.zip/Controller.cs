using System;
using System.Collections.Generic;
using System.Text;


public class Controller
{
	private readonly Dictionary<string, Category> categories;

    public Controller()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

	public string AddCategory(List<string> args)
	{
        //TODO: Implement me...
        throw new NotImplementedException();
	}

	public string AddJobOffer(List<string> args)
	{
        //TODO: Implement me...
        throw new NotImplementedException();
	}

	public string GetAverageSalary(List<string> args)
	{
        //TODO: Implement me...
        throw new NotImplementedException();
	}

	public string GetOffersAboveSalary(List<string> args)
	{
        //TODO: Implement me...
        throw new NotImplementedException();
	}

	public string GetOffersWithoutSalary(List<string> args)
	{
        //TODO: Implement me...
        throw new NotImplementedException();
	}

}