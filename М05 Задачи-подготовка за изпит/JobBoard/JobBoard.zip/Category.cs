using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Category
{
    private string name;
    private List<JobOffer> jobOffers;

    public string Name
    {
        get {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
        
        set
        {
            //TODO: Implement me...
            throw new NotImplementedException();
        }
    }

    public Category(string name)
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public void AddJobOffer(JobOffer offer)
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public double AverageSalary()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public List<JobOffer> GetOffersAboveSalary(double salary)
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public List<JobOffer> GetOffersWithoutSalary()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }

    public override string ToString()
    {
        //TODO: Implement me...
        throw new NotImplementedException();
    }
}