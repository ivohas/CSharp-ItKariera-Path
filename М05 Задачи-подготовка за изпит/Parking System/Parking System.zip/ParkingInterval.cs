using System;
using System.Collections.Generic;
using System.Text;

public class ParkingInterval
{
    private ParkingSpot parkingSpot;

    public ParkingSpot ParkingSpot
    {
        get
        {
            //TODO: implement me
            throw new NotImplementedException();
        }
        
        set
        {
            //TODO: implement me
            throw new NotImplementedException();
        }
    }

    private string registrationPlate;

    public string RegistrationPlate
    {
        get
        {
            //TODO: implement me
            throw new NotImplementedException();
        }
        
        set
        {
            //TODO: implement me
            throw new NotImplementedException();
        }
    }

    private int hoursParked;

    public int HoursParked  
    {
        get
        {
            //TODO: implement me
            throw new NotImplementedException();
        }
        
        set
        {
            //TODO: implement me
            throw new NotImplementedException();
        }
    }

    public double Revenue
    {
        get {
            //TODO: Implement me
            throw new NotImplementedException();
        }
    }

    public ParkingInterval(ParkingSpot parkingSpot, string registrationPlate, int hoursParked)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

    public override string ToString()
    {
        //TODO: Implement me
        throw new NotImplementedException();
   }
}