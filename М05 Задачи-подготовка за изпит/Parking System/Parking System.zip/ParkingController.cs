using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

internal class ParkingController
{
    private List<ParkingSpot> parkingSpots;

    public ParkingController()
    {
        parkingSpots = new List<ParkingSpot>();
    }

    public string CreateParkingSpot(List<string> args)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

    public string ParkVehicle(List<string> args)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

    public string FreeParkingSpot(List<string> args)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

    public string GetParkingSpotById(List<string> args)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

    public string GetParkingIntervalsByParkingSpotIdAndRegistrationPlate(List<string> args)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

    public string CalculateTotal(List<string> args)
    {
        //TODO: Implement me
        throw new NotImplementedException();
    }

}

